
import {launchUrl,
    registerNewUser,
    loginUser,
    verifyUserLogin,
    checkMsg,
    logOut,
    registerIncorrect} from "../actions/facebookActions";


given('I visit the facebook login page', function () {

    launchUrl();

});



When(/^I enter my registration details with (.+) and (.+)$/, function (firstname, lastname, callback) {
    
    registerNewUser(firstname, lastname);  

});


When(/^I enter my login details with (.+) and (.+)$/, function (Username, Password, callback) {

    loginUser(Username,Password);

});

Then('User is registered successfully',()=>{
    console.log("USer registered");
})

Then('I see News Feed page',()=>{
    verifyUserLogin();
})

Then ('Check the messages', function(){

    checkMsg();

});


And ('The user logs out', function(){
    
    logOut();

});


When ('I fill the registration form with incorrect details', function(){
    
    registerIncorrect();
    
});


Then ('User is not registered',function(){
    console.log("User not registered")
});