
//const baseUrl='https://www.facebook.com/';
const register_first_name='input[name="firstname"]';
const register_last_name='input[name="lastname"]';
const register_emailID='input[name="reg_email__"]';
const register_password='input[name="reg_passwd__"]';

const FBLogo='i[class="fb_logo img sp_RNXRBsVDn05 sx_43b207"]';

const login_Username='input[name="email"]';
const login_Password='input[name="pass"]';
const login_Button='input[type="submit"]';
const dropDown='#userNavigationLabel';

const MsgIcon='a[name="mercurymessages"]';

export const launchUrl=()=>{
    cy.visit("/");
    cy.server();
    //cy.route(baseUrl).as('UrlLaunch'); 
    
}

    
export const registerNewUser= (firstname,lastname) =>{
const email=firstname+"."+lastname +"@gmail.com";
const pass= firstname+lastname+"123";
cy.get(register_first_name).type(firstname);
cy.get(register_last_name).type(lastname);
cy.get(register_emailID).type(email);
cy.get(register_password).type(pass);

}


export const loginUser=(Username,Password) =>{
    cy.get(login_Username).type(Username);
    cy.get(login_Password).clear();
    cy.get(login_Password).type(Password);
    cy.get(login_Button).click();
     
   
}

export const verifyUserLogin=()=>{
    cy.get('div').contains('div','News Feed').should('be.visible');
}

export const checkMsg=() =>{
    cy.get(MsgIcon).click();
    cy.wait(3000);
}


export const logOut=() =>{
    cy.get(dropDown).click();
    cy.wait(3000);
    cy.get('span').contains('span','Log Out').click();
}


export const registerIncorrect=() =>{
    cy.get(register_first_name).type(" ");
    cy.get(register_last_name).type(" ");
    cy.get(register_emailID).type(" ");
    cy.get(register_password).type(" ");
}